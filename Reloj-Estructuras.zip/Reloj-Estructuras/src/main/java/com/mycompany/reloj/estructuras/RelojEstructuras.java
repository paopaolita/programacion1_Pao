/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.reloj.estructuras;
import Interfaz_Grafica.Bases_Proyecto;
import javax.swing.Timer;
/**
 *
 * @author Paola Gómez
 */
public class RelojEstructuras {

    public static void main(String[] args) {
         Carga_Rapida pantallaDeCarga = new Carga_Rapida();
        pantallaDeCarga.mostrarPantallaDeCarga();

        Timer temporizador = new Timer(50, e -> {
            int progreso = pantallaDeCarga.barraCarga.getValue() + 2;

            if (progreso >= 100) {
                ((Timer) e.getSource()).stop();
                pantallaDeCarga.dispose();

                Bases_Proyecto ventanaPrincipal = new Bases_Proyecto();
                ventanaPrincipal.setVisible(true);
            } else {
                pantallaDeCarga.actualizarProgreso(progreso);
            }
        });
        temporizador.start();
    }
}