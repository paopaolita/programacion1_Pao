/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.reloj.estructuras;

/**
 *
 * @author Paola Gómez
 */
import javax.swing.*;
import java.awt.*;

public class Carga_Rapida extends JWindow {
       public final JProgressBar barraCarga;

    public Carga_Rapida() {
        setSize(300, 150);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel etiquetaCargando = new JLabel("Cargando...", SwingConstants.CENTER);
        etiquetaCargando.setFont(new Font("Times new roman", Font.BOLD, 18));

        barraCarga = new JProgressBar(0, 100);
        barraCarga.setValue(0);
        barraCarga.setStringPainted(true);

        add(etiquetaCargando, BorderLayout.NORTH);
        add(barraCarga, BorderLayout.SOUTH);
    }

    public void mostrarPantallaDeCarga() {
        setVisible(true);
    }

    public void actualizarProgreso(int progreso) {
        barraCarga.setValue(progreso);
    }

}

